var client_id = "MTExNTBjNTgyOGQ0NTFiOTc0ZWI1MTg1MGQ3NmYxYjE3";
function getNearbyOrders(){
    var addressBox = document.getElementById('deliveryAddress');
    var address = addressBox.value;
    var newUrl = "http://104.131.244.218/orderbylocation?user_location="+address;
    var response = httpGet(newUrl);
    tableHeader();
    handledata(response);
    console.log(response);

}

function httpGet(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "GET", theUrl, false ); // false for synchronous request
    xmlHttp.send(null);
    return xmlHttp.responseText;
};

function addRowToTable(id, name, toGoal, distance){
    var table2 = document.getElementById("ordersNearby");
    var row2 = table2.insertRow(table2.rows.length);
    row2.id = id;
    var cell1 = row2.insertCell(0);
    var cell2 = row2.insertCell(1);
    var cell3 = row2.insertCell(2);
    cell1.innerHTML = name;
    cell2.innerHTML = distance + " meters";
    cell3.innerHTML = "$ "+toGoal;
}

function tableHeader(){
     var table2 = document.getElementById("ordersNearby");
     if (table2.tHead) return;
     var head = table2.createTHead();
     var row = head.insertRow(0)
     var cell1 = row.insertCell(0)
     var cell2 = row.insertCell(1)
     var cell3 = row.insertCell(2)

     cell1.innerHTML = "Restaurant";
     cell3.innerHTML = "To Completion"
     cell2.innerHTML = "Distance"

}

function handledata(jsonObj){
    var json = JSON.parse(jsonObj);
    for(var i=0; i<json.length; i++){
        var order = json[i];
        var merchantID = order["merchantID"];
        var orderID = order["id"];
        var reqdTotal = order["reqd_total"];
        var distance = order["distance"];
        //var currentTotal = order["currentTotal"];
        var name = populateRestaurantName(merchantID);
        addRowToTable(merchantID, name , reqdTotal, distance);
    }

}

function populateRestaurantName(id){
    var url1 = "http://sandbox.delivery.com/merchant/";
    var urlToQuery  =url1 + id +'?client_id='+client_id;
    var response = httpGet(urlToQuery);
    console.log(response);
   var response2 = JSON.parse(response);
    var name = response2["merchant"]["summary"]["name"];
    return name;
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
}

(function () {
        var elem = document.getElementById("welcome");
        elem.innerHTML = "Hi, "+getCookie("Name")+"!";
    })();
