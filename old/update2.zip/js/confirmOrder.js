(function () {


    var name = getCookie("restaurant");
    document.getElementById("rname").innerHTML = name;
    var total = getCookie("total");
    console.log(total);
    document.getElementById("total").innerHTML = "$" + total;

    console.log(document.cookie);
    var itemNames = getCookie("itemsNames").split("|");
    var itemPrices = getCookie("itemPrices").split("|");
    var itemIds = getCookie("items").split("|");
    for (var item in itemNames) {

        var name = itemNames[item];
        var price = itemPrices[item];
        var id = itemIds[item];
        addToResultTable(id, name, price);
    }

})();

function addToResultTable(id, name, price){
    var table = document.getElementById("summary");
    var row = table.insertRow(1);
    row.id = id;
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);

    cell1.innerHTML = name;
    cell2.innerHTML = price;
};



function setCookie(name, val){
    var cookieName = name;
    var cookieValue = val;
    document.cookie = cookieName +"=" + cookieValue +";path=/";

}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
}

(function () {
        var elem = document.getElementById("welcome");
        elem.innerHTML = "Hi, "+getCookie("Email")+"!";
    })();